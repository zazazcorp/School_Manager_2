/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * StaticScale
 *
 * (c) 2016 Torstein Honsi, Lars A. V. Cabrera
 *
 * --- WORK IN PROGRESS ---
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/static-scale.src.js';
