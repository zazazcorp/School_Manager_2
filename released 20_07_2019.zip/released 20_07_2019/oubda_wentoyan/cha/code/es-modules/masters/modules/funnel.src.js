/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * Highcharts funnel module
 *
 * (c) 2010-2017 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/funnel.src.js';
